/**
 * 
 */
package com.khmeracademy.mininProject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class StockMgt {
	public static void main(String[] args) {

		/*
		 * Interact with file
		 */

		ArrayList<String> arr = new ArrayList<>();
		

		try (FileWriter fw = new FileWriter("File/data.txt")) {

			for (int i = 0; i < 100_000_000; i++) {
				fw.write('a');
			}
			System.out.println("Done");

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try (BufferedReader br = new BufferedReader(new FileReader("File/data.txt"))) {
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		ArrayList<ArrayList> data = new ArrayList<>();

	}
}
