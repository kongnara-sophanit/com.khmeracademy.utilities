package com.khmeracademy.testing;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Program {
    public static void main(String[] args) throws IOException {

	ArrayList<String> list = new ArrayList<>();
	FileWriter fw = new FileWriter("testing/text.txt");
	for(int i = 0 ; i < 10000000; i++){
		fw.write("H");
	}
	// New BufferedReader.
	BufferedReader reader = new BufferedReader(new FileReader(
		"testing/text.txt"));

	// Add all lines from file to ArrayList.
	while (true) {
	    String line = reader.readLine();
	    if (line == null) {
		break;
	    }
	    list.add(line);
	}

	// Close it.
	reader.close();

	// Print size of ArrayList.
	System.out.println("Lines: " + list.size());

	// Print each line.
	for (String line : list) {
	    System.out.println(line);
	}
    }
}